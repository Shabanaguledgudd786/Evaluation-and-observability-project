# Reflection Brief — Evaluation and Observability Capstone

**Name:SHABANA .D. GULEDGUDD**
**Date:27-10-2026**

> Ground every answer in your own run. When a question asks for a number, file name, or line, paste
> it from your artifacts — a reviewer should be able to find it. Answers that are correct in the
> abstract but cite nothing do not meet the bar. Keep it short and specific.

---
## 0. Environment

| Field | Value |
|---|---|
| OS & version | Linux; distribution/version not recorded |
| Python version | Python 3.13.0 |
| Date run | October 27, 2026 |
| Ran any system live? (which) | Attempted the policy pipeline live, but the API rejected the configured `claude-haiku-4-5` model under the key's model policy. No successful live run is claimed. Mortgage and supply-chain evidence was collected in offline/replay modes. |


## 1. Validated, routed pipeline

| Evidence | Value |
|---|---|
| Passing test count | 45 passed, 3 skipped; routing-specific tests: 9 passed in 0.10s |
| Routing output file | `01-policy-pipeline/offline-routing-decision.json` contains a constructed offline routing test record. The live pipeline attempt failed with HTTP 400 because the configured model was not permitted. See `01-policy-pipeline/pipeline-run.txt`. |
| auto_approve / human_review / spot_check counts | Controlled offline record: 0 auto_approve, 1 human_review, 0 spot_check. These are counts from the single constructed test record, not from the live policy batch. |

**1a. Retry boundary.** The test `test_ac_01_04_missing_source_halts_immediately` passed (`1 passed, 13 deselected in 0.07s`). It checks a missing required `endorsements` field, the `endorsements_absent` pattern, and `RetryFutileEscalation`. The mock client's call count is one; this is a test call, not a live API call. Retrying cannot recover information absent from the source, so escalation avoids futile calls and preserves the issue for human review.

**1b. Reading the router.** The controlled offline record in `01-policy-pipeline/offline-routing-decision.json` has policy ID `OFFLINE-TEST-POLICY-001` and decision `human_review`. Its reason is `fields_below_threshold=['premium_amount']`: the premium confidence is 0.65, below the configured 0.90 threshold. This is a constructed routing test record, not a live extraction result. The live pipeline did not complete because the API rejected the configured model. The offline test demonstrates how the router handles low confidence; it does not establish the routing outcome for the original policy documents.

**1c. Where the aggregate lies.** From `01-policy-pipeline/calibration-report.txt`:

`umbrella exclusions n=2 conf=0.93 acc=0.00 brier=0.865`

`OVERALL brier=0.291`

The `umbrella × exclusions` cell has 93% confidence but 0% accuracy across two samples. Slicing by policy type and field exposes a poorly performing subgroup that an aggregate score can hide.


## 2. Schema-enforced two-pass extraction

| Evidence | Value |
|---|---|
| Passing test count | 25 passed (`02-mortgage-extraction/tests.txt`) |
| Document run | `02-mortgage-extraction/discrepancy-run.txt` |
| Classified type | Income/paystub document |

**2a. Two guarantees.** The discrepancy run reports a calculated monthly total of $9,642.17 versus a stated total of $10,892.17. The validator flags `total_monthly_income` with a discrepancy of -$1,250 and marks the result inconsistent.

Schema validation checks the structure and types of returned data, but cannot guarantee the arithmetic is correct. Mathematical validation checks relationships between values, but cannot guarantee that the source document is authentic or that a value was transcribed from the correct line.

**2b. Refusing to fabricate.** In `02-mortgage-extraction/missing-bonus-run.txt`, `bonus_monthly` and `bonus_ytd` are `null` because the bonus information is absent. The schema permits this: `models.py` defines `bonus_monthly: float | None = None`, and `schema.py` allows `"type": ["number", "null"]`. The output's `consistent: true` does not prove total income is established, because no stated total was available to compare.

**2c. Normalization.** The source `fixtures/documents/appraisal_informal_sqft.txt` says `Gross Living Area: approximately 2,400 sq ft (above-grade finished)`. The extracted output in `02-mortgage-extraction/extract-run.txt` represents this as `"gross_living_area_sqft": 2400`. Normalizing during extraction provides a consistent numeric value for validation and downstream calculations.


## 3. Multi-source synthesis

| Evidence | Value |
|---|---|
| Passing test count | 34 passed in 44.83s (`03-supply-chain/tests.txt`) |
| Briefing file | `03-supply-chain/investigation-run.txt` |
| Section the conflict landed in | `## Contested` |

**3a. Annotate, don't arbitrate.** The normal briefing reports `on_time_delivery_rate` as 95.0 percent from `supplier_audit` (as of 2026-04-10) and 78.0 percent from `logistics` (as of 2026-04-05). Both values are marked as conflicting, and the high-impact metric is escalated. Preserving both values lets a reader investigate differences in measurement periods, definitions, or source reliability rather than treating an unsupported reconciliation as fact.

**3b. Source goes dark.** The timeout briefing states: `Sources unavailable: logistics unavailable (timeout)`. It marks `late_shipment_count` incomplete because logistics timed out. The delivery rate appears as a single-source value of 95.0% from `supplier_audit`; the 78% logistics comparison is unavailable. `production_capacity_utilization` remains incomplete because no source reported it. An unreachable source is an access failure, not an empty result or proof that nothing happened. The coordinator finishes by preserving available claims and annotating the evidence gap.

**3c. Dates as a guardrail.** The normal briefing reports defect rates of 180.0 ppm from `supplier_audit` as of 2026-04-10 and 190.0 ppm from `internal_quality` as of 2026-04-08. Keeping the dates visible warns readers that the figures may describe different observation times; the difference should be investigated rather than automatically treated as a same-period contradiction.


## 4. Synthesis

**4a. One principle.** The clearest example is `02-mortgage-extraction/discrepancy-run.txt`: the extracted monthly income components total $9,642.17, but the document states $10,892.17. Mathematical validation flags a $1,250 difference and marks the result inconsistent instead of trusting a structurally valid extraction.

**4b. Confidence ≠ correctness.** The policy calibration report shows `umbrella × exclusions` with confidence 0.93 but accuracy 0.00 across two samples, and a Brier score of 0.865. The overall Brier score is 0.291. This subgroup result shows why confidence alone is not sufficient evidence of correctness. The sample is small, so it signals a calibration concern rather than proving a universal failure.

**4c. Apply it.** For an LLM extracting financial figures from paystubs, I would start with schema-enforced extraction followed by deterministic validation and escalation for inconsistent totals. I would instrument schema-validation failures, missing-field rates, arithmetic discrepancies and their sizes, retry counts, escalation rates, and outcomes after human review. I would retain source provenance and test performance on deliberately perturbed documents. These signals would help detect when extraction quality changes instead of relying only on the model's confidence.

