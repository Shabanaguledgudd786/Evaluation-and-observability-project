# Perturbation Log

For each system, make one deliberate change to an input or configuration, predict the outcome, run
it, and record what actually happened. See the starters in the Instructions, or design your own (your
own experiment earns more credit).

---

### System 1 — validated, routed pipeline

- **Change I made (file + what I changed):**
- **Command I ran:**
- **What I predicted:**
- **What actually happened (paste the key output line):**
- **How this differs from the unperturbed run:**

---

### System 2 — schema-enforced two-pass extraction

- **Change I made (file + what I changed):**
- **Command I ran:**
- **What I predicted:**
- **What actually happened (paste the key output line):**
- **How this differs from the unperturbed run:**

---

### System 3 — multi-source synthesis

- **Change I made (file + what I changed):**
- **Command I ran:**
- **What I predicted:**
- **What actually happened (paste the key output line):**
- **How this differs from the unperturbed run:**

## Mortgage extraction — changed stated monthly total

**Change I made (file + what I changed):** Created `02-mortgage-extraction/income_sum_mismatch_perturbed.txt` as a copy of the original income statement and changed `TOTAL MONTHLY EARNINGS` from `$10,892.17` to `$11,892.17`. The original line-item sum is `$9,642.17`.

**Command I ran:** Ran the mortgage extractor in replay mode against the perturbed copy, then ran `tests/test_us04_validator.py`.

**What I predicted:** The validator should flag a discrepancy when the calculated and stated totals differ by more than the configured $1 tolerance.

**What actually happened:** Replay mode failed because there was no recorded response for the modified input (`No recorded response for key 646f13fc8b60b03b`). I did not switch to record or auto mode, to avoid an unapproved live API call. The focused validator suite passed: `8 passed in 1.67s`, including `test_ac_04_04_real_paystub_with_sum_mismatch_is_flagged`.

**How this differs from the unperturbed run:** The stated total in the copied document is $1,000 higher than before. The validator tests confirm that mismatches beyond tolerance are flagged, but the edited document itself was not successfully extracted end to end.

## Policy extraction — API limitation and offline routing fallback

**Change I made (file + what I changed):** No policy source code or policy document was changed for this fallback. The attempted live pipeline used the provided policy documents, but the API rejected the configured model because the key's policy did not include `claude-haiku-4-5`.

**Command I ran:** Ran `tests/test_us04_routing.py` with the policy solution's virtual environment and saved the output to `01-policy-pipeline/routing-tests.txt`.

**What I predicted:** The offline routing tests would demonstrate the documented routing behavior without requiring another live API call.

**What actually happened:** `9 passed in 0.10s`. Tests covered auto-approval, human-review routing, reviewer disagreement, spot-check sampling, calibration reporting, and JSON output behavior. The live pipeline did not complete, and no successful live routing output is claimed.

**How this differs from the unperturbed run:** The live pipeline could not be verified because of the API model-policy restriction. The documented offline fallback verified routing behavior through tests, but it did not extract the policy documents or generate live routing decisions.

## Supply-chain investigation — logistics source timeout

**Change I made (file + what I changed):** Ran the supply-chain investigation with the logistics source timeout simulated. No source code or source data was permanently changed.

**Verified rerun command:** From the supply-chain solution directory, ran `cd "/workspace/Investigate Supply Chain Risk with Multi-Source Synthesis/03-resilient-coordinator/solution" && .venv/bin/supply-chain-investigate meridian --offline --simulate-timeout`. The output confirmed logistics timeout handling and is documented in `03-supply-chain/timeout-run.txt`. The original historical command was not recovered.

**What I predicted:** The investigation would finish even if logistics became unavailable, explicitly mark logistics-dependent evidence as incomplete, and avoid presenting unavailable comparisons as confirmed facts.

**What actually happened:** The report completed and displayed `Sources unavailable: logistics unavailable (timeout)`. `late_shipment_count` was marked incomplete because logistics timed out. `on_time_delivery_rate` appeared as a single-source value of 95.0% from supplier_audit, and the Contested section was empty. `production_capacity_utilization` remained incomplete because no source reported that metric.

**How this differs from the unperturbed run:** The normal run had a logistics value of 78% for on-time delivery, conflicting with the supplier audit's 95%. During the timeout run, the logistics comparison was unavailable, so the 95% value became single-source rather than corroborated or contested. The investigation still completed and clearly marked missing evidence.

## Follow-up offline policy evidence

**Controlled premium perturbation — evidence file:** `01-policy-pipeline/premium-perturbation-offline.txt`

**Input change:** Used constructed offline validator inputs with a stated premium of 1847.62 and component values summing to 1847.62. Then changed only the stated premium to 1947.62 while leaving the component values unchanged.

**Exact reproducible command (run from the policy solution directory):**

```bash
python3 -c 'from policy_extractor.validator import validate_extraction; from dataclasses import asdict; base={"policy_id":"OFFLINE-TEST-POLICY-001","policy_type":"auto","premium_amount":1847.62,"deductible":500.0,"coverage_limit":100000.0,"endorsements":[],"exclusions":[],"premium_components":[{"name":"base","amount":1500.0},{"name":"fees","amount":347.62}]}; changed={**base,"premium_amount":1947.62}; print("BASELINE:", asdict(validate_extraction(base)) if validate_extraction(base) else None); result=validate_extraction(changed); print("PERTURBED:", asdict(result) if result else None)'
```

**Verified reproducible command:** From the policy solution directory, I ran the following offline validator test as a follow-up rerun. The original historical command was not recovered.

The command constructed a baseline record with a stated premium of 1847.62 and components summing to 1847.62, then changed only the stated premium to 1947.62 and called `validate_extraction` on both records. The baseline returned `None`; the perturbed record returned `premium_does_not_match_components` with a +100.00 difference.

This was a constructed offline validator test, not an extraction of the original policy document. No API call was made.

**Observed result:** The baseline returned no validation error. The perturbed input returned `premium_does_not_match_components`, with stated premium 1947.62, component sum 1847.62, and delta +100.00. This is a controlled offline validator experiment, not an end-to-end extraction of the original policy document. The component breakdown was constructed for the experiment and is not claimed to come from the policy source.

**Controlled routing record — evidence file:** `01-policy-pipeline/offline-routing-decision.json`

**Input and observed result:** Constructed policy ID `OFFLINE-TEST-POLICY-001` had `premium_amount` confidence 0.65, below the configured 0.90 threshold. The existing routing function returned `human_review` with reason `fields_below_threshold=['premium_amount']`. This demonstrates the offline routing rule and JSON serialization; it is not a live extraction or a routing decision for any of the original policy documents.

**Live pipeline limitation remains unchanged:** The attempted live policy pipeline failed with HTTP 400 because the configured `claude-haiku-4-5` model was not permitted by the API key's model policy. No successful live pipeline run is claimed, and no further live API calls were made for these offline experiments.

